changelog:

- about_us.php: Changed "Our Happy Clients" to "Sponsors"; commented out "our-clients" div
- our_focus.php: See comments.
- footer.php: see comments.